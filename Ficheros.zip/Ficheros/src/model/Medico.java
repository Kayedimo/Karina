package model;
public class Medico {

		private int id_Medico;
		private String nombre;
		
		
		
		
		public Medico(int id_Medico, String nombre) {
			this.id_Medico = id_Medico;
			this.nombre = nombre;
		}
		public Medico() {
			
		}
		public int getId_Medico() {
			return id_Medico;
		}
		public void setId_Medico(int id_Medico) {
			this.id_Medico = id_Medico;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		
		
}

