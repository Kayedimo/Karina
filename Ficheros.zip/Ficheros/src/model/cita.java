package model;
import java.time.LocalDateTime;

public class cita {

	
		private int id;
		private String clave;
		private int id_Medico;
		private LocalDateTime fecha;
		private int sala;
		
		
		
		public cita() {
	
		}
		public cita(int id, String clave, int id_Medico, LocalDateTime fecha, int sala) {
			
			this.id = id;
			this.clave = clave;
			this.id_Medico = id_Medico;
			this.fecha = fecha;
			this.sala = sala;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getClave() {
			return clave;
		}
		public void setClave(String clave) {
			this.clave = clave;
		}
		public int getIdMedico() {
			return id_Medico;
		}
		public void setIdMedico(int idMedico) {
			this.id_Medico = idMedico;
		}
		public LocalDateTime getFecha() {
			return fecha;
		}
		public void setFecha(LocalDateTime fecha) {
			this.fecha = fecha;
		}
		public int getSala() {
			return sala;
		}
		public void setSala(int sala) {
			this.sala = sala;
		}
	
		
}

