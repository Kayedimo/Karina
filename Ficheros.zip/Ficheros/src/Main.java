import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import model.cita;

public class Main {

	
	HashMap<Integer, cita> mis_citas = new HashMap<Integer, cita>();
	
	String ruta = "C:\\RMS\\";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Main m = new Main();
		m.run();
		
		
		
	}
	
	public void run() {
		LocalDateTime l = LocalDateTime.of(2025,6,4,18,20,00);
		
		
		cita c1 = new cita(6,"VJ37",21,l,312);
		
		mis_citas.put(c1.getId(),c1);
		
		
		CargaCitas(ruta+ "citas.csv");
		VuelcaCitas(ruta+"ocitas.csv");
		
	}

	
	public void CargaCitas(String NombreFichero) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(NombreFichero));
			
			String linea = "";
			
			while((linea = br.readLine()) != null) {
			
				String[] datos = linea.split(";");
				cita cc = new cita(Integer.parseInt(datos[0]) ,datos[1],Integer.parseInt(datos[2]),LocalDateTime.parse(datos[3]+":00",dtf) ,Integer.parseInt(datos[4]));
				
				mis_citas.put(cc.getId(),cc);
				
			}
			
			br.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
	
		
	}
	
	public void VuelcaCitas(String NombreFichero) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter (NombreFichero,true)); //el true sirve para no borrar lo que ya haya
		
			for(HashMap.Entry<Integer,cita> item:mis_citas.entrySet()){
			
				Integer clave = item.getKey();
				cita valor = item.getValue();
			
				bw.write(valor.getSala()+ "#"+ valor.getFecha().format(dtf).toString()+ "#"+ valor.getClave());
				bw.newLine();
			
			}
			bw.close();		
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
}

